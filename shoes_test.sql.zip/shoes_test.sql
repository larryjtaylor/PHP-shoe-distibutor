-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 24, 2017 at 06:54 AM
-- Server version: 5.6.35
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_name` varchar(30) DEFAULT NULL,
  `price` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `brand_id`, `store_id`) VALUES
(1, 10, 1),
(2, 11, 2),
(3, 11, 3),
(4, 12, 15),
(5, 13, 16),
(6, 14, 16),
(7, 24, 17),
(8, 25, 18),
(9, 25, 19),
(10, 26, 31),
(11, 27, 32),
(12, 28, 32),
(13, 38, 33),
(14, 39, 34),
(15, 39, 35),
(16, 40, 47),
(17, 41, 48),
(18, 42, 48),
(19, 52, 49),
(20, 53, 50),
(21, 53, 51),
(22, 54, 63),
(23, 55, 64),
(24, 56, 64),
(25, 66, 65),
(26, 67, 66),
(27, 67, 67),
(28, 68, 79),
(29, 69, 80),
(30, 70, 80),
(31, 80, 81),
(32, 81, 82),
(33, 81, 83),
(34, 82, 95),
(35, 83, 96),
(36, 84, 96),
(37, 94, 97),
(38, 95, 98),
(39, 95, 99),
(40, 96, 111),
(41, 97, 112),
(42, 98, 112),
(43, 108, 113),
(44, 109, 114),
(45, 109, 115),
(46, 110, 127),
(47, 111, 128),
(48, 112, 128),
(49, 122, 129),
(50, 123, 130),
(51, 123, 131),
(52, 124, 143),
(53, 125, 144),
(54, 126, 144),
(55, 136, 145),
(56, 137, 146),
(57, 137, 147),
(58, 138, 159),
(59, 139, 160),
(60, 140, 160),
(61, 150, 161),
(62, 151, 162),
(63, 151, 163),
(64, 152, 175),
(65, 153, 176),
(66, 154, 176);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `store_name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
